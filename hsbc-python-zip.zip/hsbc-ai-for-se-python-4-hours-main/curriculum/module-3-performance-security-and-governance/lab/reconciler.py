"""End-of-day reconciliation helpers.

They work, but they are slow and verbose. THIS is the file you refactor with your AI assistant.
The rule: behaviour must not change. The tests in tests/ are your safety net.
"""
from collections import Counter, defaultdict
from decimal import Decimal

from transactions import Transaction


def find_duplicate_ids(transactions: list[Transaction]) -> list[str]:
    """Ids that appear more than once, each listed once, in the order their FIRST occurrence appears."""
    seen: dict[str, bool] = {}
    for transaction in transactions:
        seen[transaction.txn_id] = transaction.txn_id in seen
    return [txn_id for txn_id, duplicated in seen.items() if duplicated]


def total_by_currency(transactions: list[Transaction]) -> dict[str, Decimal]:
    """Total amount per currency."""
    totals: defaultdict[str, Decimal] = defaultdict(Decimal)
    for transaction in transactions:
        totals[transaction.currency] += transaction.amount
    return dict(totals)


def count_by_status(transactions: list[Transaction]) -> dict[str, int]:
    """Number of transactions per status."""
    counts = Counter(transaction.status for transaction in transactions)
    return dict(counts)
